chipKIT-TFT
===========

Universal TFT and other display device library for the chipKIT and PIC32 based boards.

# THIS LIBRARY HAS BEEN DEPRECATED.

# INSTEAD USE THE DisplayCore LIBRARY

http://github.com/MajenkoLibraries/DisplayCore
